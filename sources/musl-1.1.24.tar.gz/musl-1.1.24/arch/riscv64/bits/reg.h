#undef __WORDSIZE
#define __WORDSIZE 64
#define REG_PC 0
#define REG_RA 1
#define REG_SP 2
#define REG_TP 4
#define REG_S0 8
#define REG_A0 10
