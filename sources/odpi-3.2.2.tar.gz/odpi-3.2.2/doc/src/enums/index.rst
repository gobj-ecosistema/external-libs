*******************
ODPI-C Enumerations
*******************

.. toctree::
    :maxdepth: 1

    dpiAuthMode<dpiAuthMode.rst>
    dpiConnCloseMode<dpiConnCloseMode.rst>
    dpiCreateMode<dpiCreateMode.rst>
    dpiDeqMode<dpiDeqMode.rst>
    dpiDeqNavigation<dpiDeqNavigation.rst>
    dpiEventType<dpiEventType.rst>
    dpiExecMode<dpiExecMode.rst>
    dpiFetchMode<dpiFetchMode.rst>
    dpiMessageDeliveryMode<dpiMessageDeliveryMode.rst>
    dpiMessageState<dpiMessageState.rst>
    dpiNativeTypeNum<dpiNativeTypeNum.rst>
    dpiOpCode<dpiOpCode.rst>
    dpiOracleTypeNum<dpiOracleTypeNum.rst>
    dpiPoolCloseMode<dpiPoolCloseMode.rst>
    dpiPoolGetMode<dpiPoolGetMode.rst>
    dpiPurity<dpiPurity.rst>
    dpiShutdownMode<dpiShutdownMode.rst>
    dpiSodaFlags<dpiSodaFlags.rst>
    dpiStartupMode<dpiStartupMode.rst>
    dpiStatementType<dpiStatementType.rst>
    dpiSubscrGroupingClass<dpiSubscrGroupingClass.rst>
    dpiSubscrGroupingType<dpiSubscrGroupingType.rst>
    dpiSubscrNamespace<dpiSubscrNamespace.rst>
    dpiSubscrProtocol<dpiSubscrProtocol.rst>
    dpiSubscrQOS<dpiSubscrQOS.rst>
    dpiVisibility<dpiVisibility.rst>
